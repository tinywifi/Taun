package com.taun.mixin;

import com.taun.TaunCore;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Intercepts command sending to block specific commands from ALL sources
 * (manual typing, other mods, macros, etc.)
 */
@Mixin(class_634.class)
public class CommandBlockerMixin {
    
    /**
     * Intercept sendChatCommand which is called for ALL /commands
     */
    @Inject(method = "sendChatCommand", at = @At("HEAD"), cancellable = true)
    private void blockCommand(String command, CallbackInfo ci) {
        TaunCore.LOGGER.info("DEBUG: sendChatCommand intercepted: '{}'", command);
        if (TaunCore.isCommandBlocked(command)) {
            TaunCore.LOGGER.info("DEBUG: Blocking command '{}'", command);
            // Cancel the command from being sent
            ci.cancel();
            
            // Show message to player
            class_310 client = class_310.method_1551();
            if (client.field_1724 != null) {
                long remainingSeconds = TaunCore.getCommandBlockTimeRemaining(command);
                client.field_1724.method_7353(
                    class_2561.method_43470("§c[BLOCKED] §7Command blocked for " + remainingSeconds + " more seconds"), 
                    false
                );
            }
        }
    }
    
    /**
     * Also intercept sendChatMessage in case mods use this instead
     * This catches commands sent as chat messages starting with /
     */
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    private void blockChatCommand(String message, CallbackInfo ci) {
        TaunCore.LOGGER.info("DEBUG: sendChatMessage intercepted: '{}'", message);
        // Check if it's a command (starts with /)
        if (message != null && message.startsWith("/")) {
            String command = message.substring(1); // Remove the /
            if (TaunCore.isCommandBlocked(command)) {
                TaunCore.LOGGER.info("DEBUG: Blocking chat command '{}'", command);
                // Cancel the message from being sent
                ci.cancel();
                
                // Show message to player
                class_310 client = class_310.method_1551();
                if (client.field_1724 != null) {
                    long remainingSeconds = TaunCore.getCommandBlockTimeRemaining(command);
                    client.field_1724.method_7353(
                        class_2561.method_43470("§c[BLOCKED] §7Command blocked for " + remainingSeconds + " more seconds"), 
                        false
                    );
                }
            }
        }
    }
}
